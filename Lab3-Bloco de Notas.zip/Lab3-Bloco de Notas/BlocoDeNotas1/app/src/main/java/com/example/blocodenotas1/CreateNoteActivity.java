package com.example.blocodenotas1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class CreateNoteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_note);

        // Inicializando as views
        EditText edtarTitulo = findViewById(R.id.edtarTitulo);
        EditText edtarConteudo = findViewById(R.id.edtarConteudo);
        Button btOk = findViewById(R.id.btOk);
        Button btCancelar = findViewById(R.id.btCancelar);

        // Botão OK: retorna o título e conteúdo para a atividade principal
        btOk.setOnClickListener(v -> {
            Intent resultIntent = new Intent();
            resultIntent.putExtra("titulo", edtarTitulo.getText().toString());
            resultIntent.putExtra("conteudo", edtarConteudo.getText().toString());
            setResult(RESULT_OK, resultIntent);
            finish();  // Encerra a atividade
        });

        // Botão Cancelar: encerra a atividade sem salvar nada
        btCancelar.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });
    }
}

