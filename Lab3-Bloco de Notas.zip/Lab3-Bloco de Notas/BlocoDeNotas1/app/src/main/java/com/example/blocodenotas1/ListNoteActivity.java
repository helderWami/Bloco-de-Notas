package com.example.blocodenotas1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ListNoteActivity extends AppCompatActivity {

    private ArrayList<String> titulos = new ArrayList<>();
    private ArrayList<String> conteudos = new ArrayList<>();
    private ArrayAdapter<String> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.listView);
        Button btNota = findViewById(R.id.btNota);

        // adapter para preencher o array ListView com títulos
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, titulos);
        listView.setAdapter(adapter);

        // botão para criar o 'New Note'
        btNota.setOnClickListener(v -> {
            Intent intent = new Intent(ListNoteActivity.this, CreateNoteActivity.class);
            startActivityForResult(intent, 1);

        });

        // exibir o conteúdo da nota após click
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(ListNoteActivity.this, ReadNoteActivity.class);
            intent.putExtra("titulo", titulos.get(position));
            intent.putExtra("conteudo", conteudos.get(position));
            startActivity(intent);
        });

    }

    // Atualizar a lista após a criação de uma nova nota

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            // para saber se o resultado veio do create e se foi bem sucedido
            String titulo = data.getStringExtra("titulo");
            String conteudo = data.getStringExtra("conteudo");

            titulos.add(titulo);
            conteudos.add(conteudo);

            adapter.notifyDataSetChanged();
        }

    }
}
