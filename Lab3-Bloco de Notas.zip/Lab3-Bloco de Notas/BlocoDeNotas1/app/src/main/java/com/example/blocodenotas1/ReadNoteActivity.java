package com.example.blocodenotas1;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ReadNoteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_note);

        TextView textTitulo = findViewById(R.id.textTitulo);
        TextView textConteudo = findViewById(R.id.textConteudo);
        Button btVoltar = findViewById(R.id.btVoltar);

        String titulo = getIntent().getStringExtra("titulo");
        String conteudo = getIntent().getStringExtra("conteudo");

        textTitulo.setText(titulo);
        textConteudo.setText(conteudo);
    }

    /* btVoltar.setOnClickListener(v -> {

        finish();
    });

     */
    public void voltar(View view) {
        finish();
    }
}

